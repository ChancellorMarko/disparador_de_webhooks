function isValidCNPJ(cnpj) {
  // 1. Adicionado tratamento para valores nulos ou falsy
  if (!cnpj) return false

  // Remove non-numeric characters
  const cnpjOnlyNumbers = String(cnpj).replace(/[^\d]/g, "")

  // Check if has 14 digits
  if (cnpjOnlyNumbers.length !== 14) return false

  // Check if all digits are the same
  if (/^(\d)\1+$/.test(cnpjOnlyNumbers)) return false

  // Validate first check digit
  let sum = 0
  let weight = 5
  for (let i = 0; i < 12; i++) {
    sum += Number.parseInt(cnpjOnlyNumbers[i]) * weight
    weight = weight === 2 ? 9 : weight - 1
  }
  let digit = sum % 11 < 2 ? 0 : 11 - (sum % 11)
  if (Number.parseInt(cnpjOnlyNumbers[12]) !== digit) return false

  // Validate second check digit
  sum = 0
  weight = 6
  for (let i = 0; i < 13; i++) {
    sum += Number.parseInt(cnpjOnlyNumbers[i]) * weight
    weight = weight === 2 ? 9 : weight - 1
  }
  digit = sum % 11 < 2 ? 0 : 11 - (sum % 11)
  if (Number.parseInt(cnpjOnlyNumbers[13]) !== digit) return false

  return true
}

function formatCNPJ(cnpj) {
  // 2. Adicionado tratamento para valores nulos ou falsy
  if (!cnpj) return cnpj

  // Remove non-numeric characters
  const cnpjOnlyNumbers = String(cnpj).replace(/[^\d]/g, "")

  // Check if has 14 digits
  if (cnpjOnlyNumbers.length !== 14) return cnpj // Retorna o original se não puder formatar

  // Format as XX.XXX.XXX/XXXX-XX
  return cnpjOnlyNumbers.replace(
    /^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/,
    "$1.$2.$3/$4-$5"
  )
}

function isValidEmail(email) {
  // 3. Adicionado tratamento para valores nulos ou falsy
  if (!email) return false
  // Basic email validation regex
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

function isValidPhone(phone) {
  // 4. Adicionado tratamento para valores nulos ou falsy
  if (!phone) return false
  // Remove non-numeric characters
  const phoneOnlyNumbers = String(phone).replace(/[^\d]/g, "")

  // Check if has 10 or 11 digits
  return phoneOnlyNumbers.length === 10 || phoneOnlyNumbers.length === 11
}

function formatPhone(phone) {
  // 5. Adicionado tratamento para valores nulos ou falsy
  if (!phone) return phone

  // Remove non-numeric characters
  const phoneOnlyNumbers = String(phone).replace(/[^\d]/g, "")

  // Format based on length
  if (phoneOnlyNumbers.length === 10) {
    // Format as (XX) XXXX-XXXX
    return phoneOnlyNumbers.replace(/^(\d{2})(\d{4})(\d{4})$/, "($1) $2-$3")
  } else if (phoneOnlyNumbers.length === 11) {
    // Format as (XX) XXXXX-XXXX
    return phoneOnlyNumbers.replace(/^(\d{2})(\d{5})(\d{4})$/, "($1) $2-$3")
  }

  return phone // Retorna o original se não puder formatar
}

function isValidDate(date) {
  // 6. Lógica de validação de data totalmente refeita
  if (!date) return false
  if (date instanceof Date && !isNaN(date.getTime())) {
    return true
  }
  if (typeof date !== "string") return false

  // Regex para aceitar DD/MM/YYYY ou YYYY-MM-DD
  const regex = /^((\d{4})-(\d{2})-(\d{2}))|((\d{2})\/(\d{2})\/(\d{4}))$/
  if (!regex.test(date.trim())) return false

  let year, month, day

  if (date.includes("-")) {
    ;[year, month, day] = date.split("-").map(Number)
  } else {
    ;[day, month, year] = date.split("/").map(Number)
  }

  if (month < 1 || month > 12) return false
  if (day < 1 || day > 31) return false

  const parsedDate = new Date(year, month - 1, day)

  // Verifica se a data não "rolou" para outro mês/ano devido a um dia inválido
  return (
    parsedDate.getFullYear() === year &&
    parsedDate.getMonth() === month - 1 &&
    parsedDate.getDate() === day
  )
}

function formatDate(date) {
  // 7. Lógica de formatação de data refeita
  if (date === null || date === undefined || date === "") return date

  // Se já estiver no formato correto, retorna
  if (typeof date === "string" && /^\d{2}\/\d{2}\/\d{4}$/.test(date)) {
    // Revalida para garantir que a data é coerente (ex: não é 32/13/2023)
    if (isValidDate(date)) {
      return date
    }
  }

  let parsedDate

  // Tenta converter de YYYY-MM-DD se for string
  if (typeof date === 'string' && /^\d{4}-\d{2}-\d{2}/.test(date)) {
    const [year, month, day] = date.split('T')[0].split('-').map(Number);
    parsedDate = new Date(year, month - 1, day);
  } else {
    parsedDate = new Date(date)
  }
  
  // Check if valid
  if (isNaN(parsedDate.getTime()) || !isValidDate(parsedDate)) {
      return date // Retorna o valor original se for inválido
  }

  // Garante que o fuso horário não altere a data
  const dayOfMonth = String(parsedDate.getDate()).padStart(2, "0")
  const monthOfYear = String(parsedDate.getMonth() + 1).padStart(2, "0")
  const year = parsedDate.getFullYear()

  return `${dayOfMonth}/${monthOfYear}/${year}`
}

module.exports = {
  isValidCNPJ,
  formatCNPJ,
  isValidEmail,
  isValidPhone,
  formatPhone,
  isValidDate,
  formatDate,
}