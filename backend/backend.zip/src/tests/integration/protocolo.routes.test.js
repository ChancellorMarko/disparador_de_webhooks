// tests/integration/protocolo.routes.test.js
// VERSÃO CORRIGIDA

const request = require('supertest');
const app = require('../../app'); // CORREÇÃO AQUI
const jwt = require('jsonwebtoken');
const ProtocoloService = require('../../services/ProtocoloService'); // CORREÇÃO AQUI

jest.mock('jsonwebtoken');
jest.mock('../../services/ProtocoloService'); // CORREÇÃO AQUI

describe('Rota de Protocolos - GET /api/protocolos', () => {
  // O restante do arquivo continua exatamente o mesmo...
  let mockToken;

  beforeEach(() => {
    jest.clearAllMocks();
    mockToken = 'valid-jwt-token';
    jwt.verify.mockReturnValue({ softwareHouseId: 1 });
  });

  it('deve retornar erro 400 se o filtro start_date for obrigatório e não for fornecido', async () => {
    const response = await request(app)
      .get('/api/protocolos?end_date=2025-10-10')
      .set('Authorization', `Bearer ${mockToken}`)
      .expect(400);

    expect(response.body.error).toContain('"start_date" is required');
  });
  
  it('deve retornar erro 400 se o intervalo de datas for maior que 31 dias', async () => {
    const response = await request(app)
      .get('/api/protocolos?start_date=2025-01-01&end_date=2025-03-01')
      .set('Authorization', `Bearer ${mockToken}`)
      .expect(400);

    expect(response.body.error).toContain('O intervalo entre as datas não pode exceder 31 dias');
  });

  it('deve retornar 200 com uma consulta válida', async () => {
    ProtocoloService.findAll.mockResolvedValue([{ id: 1, protocolo: 'mock-uuid' }]);

    const response = await request(app)
      .get('/api/protocolos?start_date=2025-10-01&end_date=2025-10-15')
      .set('Authorization', `Bearer ${mockToken}`)
      .expect(200);

    expect(response.body.success).toBe(true);
    expect(Array.isArray(response.body.data)).toBe(true);
  });
});