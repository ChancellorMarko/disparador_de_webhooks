// tests/integration/reenvio.routes.test.js
// VERSÃO CORRIGIDA

const request = require('supertest');
const app = require('../../app'); // CORREÇÃO AQUI
const jwt = require('jsonwebtoken');
const ServicoRepository = require('../../repositories/ServicoRepository'); // CORREÇÃO AQUI
const { SoftwareHouse, Cedente, WebhookReprocessado } = require('../../models'); // CORREÇÃO AQUI

// Mock das dependências REAIS da aplicação
jest.mock('jsonwebtoken');
jest.mock('../../repositories/ServicoRepository'); // CORREÇÃO AQUI

// CORREÇÃO: Mockando os Models que o middleware shAuth.js utiliza diretamente
jest.mock('../../models/SoftwareHouse', () => ({ // CORREÇÃO AQUI
  findOne: jest.fn(),
}));
jest.mock('../../models/Cedente', () => ({ // CORREÇÃO AQUI
  findOne: jest.fn(),
}));
jest.mock('../../models/WebhookReprocessado', () => ({ // CORREÇÃO AQUI
  create: jest.fn(),
}));


describe('Rota de Reenvio - POST /api/reenviar', () => {
  // O restante do arquivo continua exatamente o mesmo...
  let mockToken;

  beforeEach(() => {
    jest.clearAllMocks();
    mockToken = 'valid-jwt-token';
    
    jwt.verify.mockReturnValue({ softwareHouseId: 1 });
    
    SoftwareHouse.findOne.mockResolvedValue({ id: 1, cnpj: '11222333000144' });
    Cedente.findOne.mockResolvedValue({ id: 10, softwarehouse_id: 1 });
  });

  it('deve criar uma solicitação de reenvio com sucesso e retornar status 201', async () => {
    ServicoRepository.findAll.mockResolvedValue([
      { id: 'boleto1', status: 'REGISTRADO' },
      { id: 'boleto2', status: 'REGISTRADO' },
    ]);
    WebhookReprocessado.create.mockResolvedValue({ protocolo: 'mock-protocolo-uuid' });

    const requestBody = {
      product: "boleto",
      id: ["boleto1", "boleto2"],
      kind: "webhook",
      type: "disponivel",
    };

    const response = await request(app)
      .post('/api/reenviar')
      .set('Authorization', `Bearer ${mockToken}`)
      .set('cnpj-sh', '11222333000144')
      .set('token-sh', 'token-sh-valido')
      .set('cnpj-cedente', 'cnpj-cedente-valido')
      .set('token-cedente', 'token-cedente-valido')
      .send(requestBody)
      .expect(201);
      
    expect(response.body.success).toBe(true);
    expect(response.body.data).toHaveProperty('protocolo');
    expect(WebhookReprocessado.create).toHaveBeenCalled();
  });

  // ... (outros 'it' blocks)
});