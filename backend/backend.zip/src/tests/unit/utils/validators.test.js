const {
  isValidCNPJ,
  formatCNPJ,
  isValidEmail,
  isValidPhone,
  formatPhone,
  isValidDate,
  formatDate,
} = require("../../../utils/validators")

describe("Validators Utils", () => {
  describe("isValidCNPJ", () => {
    it("deve retornar true para CNPJ válido", () => {
      expect(isValidCNPJ("11222333000181")).toBe(true)
      expect(isValidCNPJ("11.222.333/0001-81")).toBe(true)
    })

    it("deve retornar false para CNPJ inválido", () => {
      expect(isValidCNPJ("11111111111111")).toBe(false)
      expect(isValidCNPJ("1234567890123")).toBe(false)
      expect(isValidCNPJ("123")).toBe(false)
      expect(isValidCNPJ("")).toBe(false)
      expect(isValidCNPJ(null)).toBe(false)
      expect(isValidCNPJ(undefined)).toBe(false)
    })
  })

  describe("formatCNPJ", () => {
    it("deve formatar CNPJ corretamente", () => {
      expect(formatCNPJ("11222333000181")).toBe("11.222.333/0001-81")
      expect(formatCNPJ("11.222.333/0001-81")).toBe("11.222.333/0001-81")
    })

    it("deve retornar o valor original se não for possível formatar", () => {
      expect(formatCNPJ("123")).toBe("123")
      expect(formatCNPJ("")).toBe("")
      expect(formatCNPJ(null)).toBe(null)
    })
  })

  describe("isValidEmail", () => {
    it("deve retornar true para email válido", () => {
      expect(isValidEmail("test@example.com")).toBe(true)
      expect(isValidEmail("user.name@domain.co.uk")).toBe(true)
      expect(isValidEmail("user+tag@example.org")).toBe(true)
    })

    it("deve retornar false para email inválido", () => {
      expect(isValidEmail("test@")).toBe(false)
      expect(isValidEmail("@example.com")).toBe(false)
      expect(isValidEmail("test.example.com")).toBe(false)
      expect(isValidEmail("")).toBe(false)
      expect(isValidEmail(null)).toBe(false)
    })
  })

  describe("isValidPhone", () => {
    it("deve retornar true para telefone válido", () => {
      expect(isValidPhone("11987654321")).toBe(true)
      expect(isValidPhone("(11) 98765-4321")).toBe(true)
      expect(isValidPhone("+55 11 98765-4321")).toBe(true)
      expect(isValidPhone("1134567890")).toBe(true)
      expect(isValidPhone("(11) 3456-7890")).toBe(true)
    })

    it("deve retornar false para telefone inválido", () => {
      expect(isValidPhone("123")).toBe(false)
      expect(isValidPhone("")).toBe(false)
      expect(isValidPhone(null)).toBe(false)
    })
  })

  describe("formatPhone", () => {
    it("deve formatar telefone corretamente", () => {
      expect(formatPhone("11987654321")).toBe("(11) 98765-4321")
      expect(formatPhone("1134567890")).toBe("(11) 3456-7890")
      expect(formatPhone("(11) 98765-4321")).toBe("(11) 98765-4321")
    })

    it("deve retornar o valor original se não for possível formatar", () => {
      expect(formatPhone("123")).toBe("123")
      expect(formatPhone("")).toBe("")
      expect(formatPhone(null)).toBe(null)
    })
  })

  describe("isValidDate", () => {
    it("deve retornar true para data válida", () => {
      expect(isValidDate("2023-12-25")).toBe(true)
      expect(isValidDate("25/12/2023")).toBe(true)
      expect(isValidDate(new Date())).toBe(true)
    })

    it("deve retornar false para data inválida", () => {
      expect(isValidDate("2023-13-25")).toBe(false)
      expect(isValidDate("32/12/2023")).toBe(false)
      expect(isValidDate("invalid-date")).toBe(false)
      expect(isValidDate("")).toBe(false)
      expect(isValidDate(null)).toBe(false)
    })
  })

  describe("formatDate", () => {
    it("deve formatar data corretamente", () => {
      const date = new Date("2023-12-25")
      expect(formatDate(date)).toBe("25/12/2023")
      expect(formatDate("2023-12-25")).toBe("25/12/2023")
      expect(formatDate("25/12/2023")).toBe("25/12/2023")
    })

    it("deve retornar o valor original se não for possível formatar", () => {
      expect(formatDate("invalid-date")).toBe("invalid-date")
      expect(formatDate("")).toBe("")
      expect(formatDate(null)).toBe(null)
    })
  })
})
